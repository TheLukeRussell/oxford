require('../../../modules/esnext.string.replace-all');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').replaceAll;
