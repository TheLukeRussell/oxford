/// <reference types="react" />
export default function safeFindDOMNode(componentOrElement: React.ComponentClass | Element | null | undefined): Element | Text | null;
