import React from 'react';
var DropdownContext = React.createContext(null);
export default DropdownContext;