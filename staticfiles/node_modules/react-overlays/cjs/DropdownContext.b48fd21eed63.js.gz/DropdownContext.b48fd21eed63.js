"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

exports.__esModule = true;
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var DropdownContext = _react["default"].createContext(null);

var _default = DropdownContext;
exports["default"] = _default;
module.exports = exports.default;