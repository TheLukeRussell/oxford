import getScrollAccessor from './getScrollAccessor';
export default getScrollAccessor('pageXOffset');