import createWithBsPrefix from './createWithBsPrefix';
export default createWithBsPrefix('modal-body');