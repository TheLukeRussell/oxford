import React from 'react';
var FormContext = React.createContext({
  controlId: undefined
});
export default FormContext;