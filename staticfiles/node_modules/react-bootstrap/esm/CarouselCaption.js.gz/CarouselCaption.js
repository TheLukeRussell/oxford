import createWithBsPrefix from './createWithBsPrefix';
export default createWithBsPrefix('carousel-caption', {
  Component: 'div'
});