import React from 'react';
var NavContext = React.createContext(null);
export default NavContext;