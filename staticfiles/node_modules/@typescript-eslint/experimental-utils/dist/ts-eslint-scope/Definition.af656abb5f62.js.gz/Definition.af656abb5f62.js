"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const definition_1 = require("eslint-scope/lib/definition");
const Definition = definition_1.Definition;
exports.Definition = Definition;
const ParameterDefinition = definition_1.ParameterDefinition;
exports.ParameterDefinition = ParameterDefinition;
//# sourceMappingURL=Definition.js.map