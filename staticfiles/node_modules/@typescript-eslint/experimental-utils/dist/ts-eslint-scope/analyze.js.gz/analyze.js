"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const eslint_scope_1 = require("eslint-scope");
const analyze = eslint_scope_1.analyze;
exports.analyze = analyze;
//# sourceMappingURL=analyze.js.map