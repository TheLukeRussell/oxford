import { TSESTree } from '@typescript-eslint/experimental-utils';
import { ParserOptions } from './parser-options';
import { ScopeManager } from './scope/scope-manager';
export declare function analyzeScope(ast: TSESTree.Program, parserOptions: ParserOptions): ScopeManager;
//# sourceMappingURL=analyze-scope.d.ts.map