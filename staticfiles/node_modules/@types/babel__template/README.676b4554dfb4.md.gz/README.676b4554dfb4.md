# Installation
> `npm install --save @types/babel__template`

# Summary
This package contains type definitions for @babel/template ( https://github.com/babel/babel/tree/master/packages/babel-template ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/babel__template

Additional Details
 * Last updated: Wed, 13 Feb 2019 21:04:23 GMT
 * Dependencies: @types/babel__parser, @types/babel__types
 * Global values: none

# Credits
These definitions were written by Troy Gerwien <https://github.com/yortus>, Marvin Hagemeister <https://github.com/marvinhagemeister>, Melvin Groenhoff <https://github.com/mgroenhoff>.
