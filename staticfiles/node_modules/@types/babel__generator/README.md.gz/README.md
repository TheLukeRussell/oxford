# Installation
> `npm install --save @types/babel__generator`

# Summary
This package contains type definitions for @babel/generator (https://github.com/babel/babel/tree/master/packages/babel-generator).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/babel__generator.

### Additional Details
 * Last updated: Tue, 10 Dec 2019 19:31:19 GMT
 * Dependencies: [@types/babel__types](https://npmjs.com/package/@types/babel__types)
 * Global values: none

# Credits
These definitions were written by Troy Gerwien (https://github.com/yortus), Johnny Estilles (https://github.com/johnnyestilles), Melvin Groenhoff (https://github.com/mgroenhoff), Cameron Yan (https://github.com/khell), and Lyanbin (https://github.com/Lyanbin).
