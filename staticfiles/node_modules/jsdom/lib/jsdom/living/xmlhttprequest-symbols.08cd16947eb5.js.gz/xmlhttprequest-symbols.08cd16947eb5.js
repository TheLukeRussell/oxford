"use strict";

exports.flag = Symbol("flag");
exports.properties = Symbol("properties");
