export { computeAccessibleName } from "./accessible-name";
export { default as getRole } from "./getRole";
//# sourceMappingURL=index.d.ts.map