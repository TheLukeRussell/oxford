
1.0.0 / 2017-07-06
==================

  * update "mocha" to v3
  * fixed unicode URI decoding (#6)
  * add typings for Typescript
  * README: use SVG Travis-CI badge
  * add LICENSE file (MIT)
  * add .travis.yml file (testing Node.js 0.8 through 8 currently)
  * add README.md file

0.0.2 / 2014-01-27
==================

  * index: invert the path separators on Windows

0.0.1 / 2014-01-27
==================

  * initial commit
