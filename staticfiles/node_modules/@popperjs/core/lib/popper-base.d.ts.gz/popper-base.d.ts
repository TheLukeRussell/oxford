import { createPopper, popperGenerator } from "./index";
import detectOverflow from "./utils/detectOverflow";
export * from "./types";
export { createPopper, popperGenerator, detectOverflow };
