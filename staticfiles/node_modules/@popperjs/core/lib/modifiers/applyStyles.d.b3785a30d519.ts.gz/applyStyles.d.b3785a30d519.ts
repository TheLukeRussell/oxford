import { Modifier } from "../types";
export declare type ApplyStylesModifier = Modifier<"applyStyles", {}>;
declare const _default: Modifier<"applyStyles", {}>;
export default _default;
