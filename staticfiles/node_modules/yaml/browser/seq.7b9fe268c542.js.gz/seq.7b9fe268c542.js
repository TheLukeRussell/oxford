export { YAMLSeq as default } from './dist/schema/Seq'

import { warnFileDeprecation } from './dist/warnings'
warnFileDeprecation(__filename)
