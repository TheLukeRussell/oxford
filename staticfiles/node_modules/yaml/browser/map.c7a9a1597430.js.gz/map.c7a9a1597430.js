export { YAMLMap as default } from './dist/schema/Map'

import { warnFileDeprecation } from './dist/warnings'
warnFileDeprecation(__filename)
