export { pairs as default } from '../dist/tags/yaml-1.1/pairs'

import { warnFileDeprecation } from './dist/warnings'
warnFileDeprecation(__filename)
