export { set as default } from '../dist/tags/yaml-1.1/set'

import { warnFileDeprecation } from './dist/warnings'
warnFileDeprecation(__filename)
