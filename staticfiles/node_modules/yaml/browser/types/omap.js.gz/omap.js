export { omap as default } from '../dist/tags/yaml-1.1/omap'

import { warnFileDeprecation } from './dist/warnings'
warnFileDeprecation(__filename)
