'use strict'
Object.defineProperty(exports, '__esModule', { value: true })

exports.binary = require('../dist/tags/yaml-1.1/binary').binary
exports.default = [exports.binary]

require('../dist/warnings').warnFileDeprecation(__filename)
