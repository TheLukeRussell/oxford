module.exports = require('../dist/tags/yaml-1.1/pairs').pairs
require('../dist/warnings').warnFileDeprecation(__filename)
